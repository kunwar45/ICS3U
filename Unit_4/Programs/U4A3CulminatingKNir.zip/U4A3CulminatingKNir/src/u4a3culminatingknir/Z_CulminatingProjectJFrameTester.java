package u4a3culminatingknir;

import javax.swing.JFrame;

/**
 *
 * @author Kunwar Nir
 * 13-08-2019
 * Title: Culminating Project JFrame Tester
 * Purpose: To run the applet
 */
public class Z_CulminatingProjectJFrameTester {
    
    public static void main(String[] args) {

        A_Menu myFrame = new A_Menu(); // create LabelFrame
        myFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        myFrame.setSize(900, 900); // set frame size
        myFrame.setVisible(true); // display frame

    }

}
